<?php
		if(isset($_POST["btn"]))
		{
			$NIC=$_POST["txtnic"];
			$Email=$_POST["txtemail"];
			$Name=$_POST["txtname"];
			$Mobile_no=$_POST["txtmobile"];
			$Password=$_POST["txtpw"];
			
			
			$con=mysqli_connect("localhost","root","","mobilemart");
			if(!$con)
			{
				die("sorry, technical issue");
			}
			$sql="INSERT INTO `register` (`NIC`, `Email`, `Name`, `Mobile_no`, `Password`) VALUES ('".$NIC."', '".$Email."', '".$Name."', '".$Mobile_no."', '".$Password."');";
			mysqli_query($con,$sql);
			
		}
	
	
	?>