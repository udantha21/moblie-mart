<?php
		if(isset($_POST["btn"]))
		{
			$FullName=$_POST["txtname"];
			$Address=$_POST["txtadd"];
			$City=$_POST["txtcity"];
			$Mobile_no=$_POST["txtmobile"];
			$Email=$_POST["txtemail"];
			
			
			$con=mysqli_connect("localhost","root","","mobilemart");
			if(!$con)
			{
				die("sorry, technical issue");
			}
			$sql="INSERT INTO `payment` (`FullName`, `Address`, `City`, `Mobile_no`, `Email`) VALUES ('".$FullName."', '".$Address."', '".$City."', '".$Mobile_no."', '".$Email."');";
			mysqli_query($con,$sql);
			
		}

			
	
	?>